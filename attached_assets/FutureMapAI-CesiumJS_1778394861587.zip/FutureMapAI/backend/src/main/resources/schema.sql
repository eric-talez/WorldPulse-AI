-- FutureMap AI PostgreSQL schema draft
-- MVP는 mock data로 실행되지만, 실제 서비스 확장 시 아래 테이블을 사용하면 됩니다.

CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash TEXT,
    role VARCHAR(30) NOT NULL DEFAULT 'FREE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS country_issues (
    id UUID PRIMARY KEY,
    country_code VARCHAR(10) NOT NULL,
    country_name VARCHAR(100) NOT NULL,
    category VARCHAR(30) NOT NULL,
    title TEXT NOT NULL,
    summary TEXT NOT NULL,
    source_url TEXT,
    risk_score INT NOT NULL CHECK (risk_score BETWEEN 0 AND 100),
    latitude DOUBLE PRECISION NOT NULL,
    longitude DOUBLE PRECISION NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_country_issues_country_category
    ON country_issues(country_code, category);

CREATE TABLE IF NOT EXISTS job_future_reports (
    id UUID PRIMARY KEY,
    country_code VARCHAR(10) NOT NULL,
    country_name VARCHAR(100) NOT NULL,
    job_name VARCHAR(255) NOT NULL,
    automation_risk INT NOT NULL CHECK (automation_risk BETWEEN 0 AND 100),
    growth_score INT NOT NULL CHECK (growth_score BETWEEN 0 AND 100),
    ai_impact_summary TEXT NOT NULL,
    automated_tasks JSONB NOT NULL DEFAULT '[]',
    human_strengths JSONB NOT NULL DEFAULT '[]',
    future_changes JSONB NOT NULL DEFAULT '[]',
    recommended_skills JSONB NOT NULL DEFAULT '[]',
    country_opportunities JSONB NOT NULL DEFAULT '[]',
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_job_future_reports_country_job
    ON job_future_reports(country_code, job_name);

CREATE TABLE IF NOT EXISTS forum_posts (
    id UUID PRIMARY KEY,
    country_code VARCHAR(10) NOT NULL,
    job_name VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    likes INT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_forum_posts_country_job
    ON forum_posts(country_code, job_name);

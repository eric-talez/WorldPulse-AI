package com.futuremapai.model;

import java.time.Instant;

public record CountryIssue(
        String id,
        String countryCode,
        String countryName,
        IssueCategory category,
        String title,
        String summary,
        String sourceUrl,
        int riskScore,
        double latitude,
        double longitude,
        Instant createdAt
) {}

package com.futuremapai.service;

import com.futuremapai.dto.CreateForumPostRequest;
import com.futuremapai.model.ForumPost;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.UUID;

@Service
public class ForumService {
    private final List<ForumPost> posts = new ArrayList<>();

    public ForumService() {
        posts.add(new ForumPost(
                UUID.randomUUID().toString(),
                "KR",
                "세무사",
                "future-tax-pro",
                "AI 세무 프로그램이 실제로 세무사를 대체할까요?",
                "단순 신고 업무는 줄어들 것 같지만, 고액 자산가 상담이나 세무조사 대응은 사람이 계속 중요할 것 같습니다.",
                12,
                Instant.now().minusSeconds(3600)
        ));
        posts.add(new ForumPost(
                UUID.randomUUID().toString(),
                "US",
                "Software Engineer",
                "ai-builder",
                "AI 코딩 도구가 주니어 개발자 채용에 미치는 영향",
                "기본 코드 작성보다 요구사항 이해, 제품 감각, 시스템 설계가 더 중요해질 것 같습니다.",
                21,
                Instant.now().minusSeconds(7200)
        ));
    }

    public List<ForumPost> findPosts(String countryCode, String jobName) {
        return posts.stream()
                .filter(post -> post.countryCode().equalsIgnoreCase(countryCode))
                .filter(post -> jobName == null || jobName.isBlank() || post.jobName().equalsIgnoreCase(jobName) || post.jobName().equalsIgnoreCase("General"))
                .sorted(Comparator.comparing(ForumPost::createdAt).reversed())
                .toList();
    }

    public ForumPost createPost(CreateForumPostRequest request) {
        ForumPost post = new ForumPost(
                UUID.randomUUID().toString(),
                request.countryCode(),
                request.jobName(),
                request.author(),
                request.title(),
                request.body(),
                0,
                Instant.now()
        );
        posts.add(post);
        return post;
    }
}

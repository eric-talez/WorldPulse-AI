package com.futuremapai.dto;

public record LoginResponse(
        String token,
        String email,
        String role
) {}

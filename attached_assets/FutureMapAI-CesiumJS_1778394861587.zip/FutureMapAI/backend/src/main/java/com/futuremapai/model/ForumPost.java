package com.futuremapai.model;

import java.time.Instant;

public record ForumPost(
        String id,
        String countryCode,
        String jobName,
        String author,
        String title,
        String body,
        int likes,
        Instant createdAt
) {}

package com.futuremapai.model;

public enum IssueCategory {
    NEWS,
    WAR,
    DISEASE,
    POLITICS,
    ECONOMY,
    CULTURE,
    AI_JOBS
}

package com.futuremapai.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
public class DataIngestionScheduler {
    private static final Logger log = LoggerFactory.getLogger(DataIngestionScheduler.class);

    /**
     * MVP에서는 mock data를 사용합니다.
     * 실제 서비스 확장 시 이 스케줄러에서 다음 파이프라인을 구현하세요.
     *
     * 1. GDELT API 호출: 글로벌 뉴스/지역 언급 수집
     * 2. WHO Disease Outbreak News 호출: 감염병/보건 이슈 수집
     * 3. ACLED API 호출: 분쟁/시위/정치폭력 데이터 수집
     * 4. 국가/카테고리 분류
     * 5. 중복 제거 및 신뢰도 점수 계산
     * 6. OpenAI API로 요약 및 직업 영향 분석
     * 7. PostgreSQL 저장 + Redis 캐싱
     */
    @Scheduled(fixedDelay = 60 * 60 * 1000L)
    public void ingestExternalSignals() {
        log.info("Mock ingestion heartbeat. External APIs are not connected yet.");
    }
}

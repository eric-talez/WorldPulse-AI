package com.futuremapai.service;

import com.futuremapai.model.Country;
import com.futuremapai.model.CountryIssue;
import com.futuremapai.model.IssueCategory;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class IssueService {
    private final CountryService countryService;
    private final List<CountryIssue> issues;

    public IssueService(CountryService countryService) {
        this.countryService = countryService;
        this.issues = seedIssues();
    }

    public List<CountryIssue> findIssues(String countryCode, List<IssueCategory> categories) {
        return issues.stream()
                .filter(issue -> issue.countryCode().equalsIgnoreCase(countryCode))
                .filter(issue -> categories == null || categories.isEmpty() || categories.contains(issue.category()))
                .sorted((a, b) -> Integer.compare(b.riskScore(), a.riskScore()))
                .toList();
    }

    private List<CountryIssue> seedIssues() {
        List<CountryIssue> items = new ArrayList<>();
        addCountryIssues(items, countryService.findByCodeOrDefault("KR"), List.of(
                new Seed(IssueCategory.NEWS, "반도체·AI 인프라 투자 확대", "AI 서버와 반도체 수요가 늘면서 데이터센터, 전력, 제조업 고용 구조가 함께 바뀌고 있습니다.", 72),
                new Seed(IssueCategory.POLITICS, "디지털 규제와 플랫폼 정책 논의", "AI, 개인정보, 플랫폼 책임과 관련된 규제가 강화되며 법률·컴플라이언스 인력 수요가 커질 수 있습니다.", 58),
                new Seed(IssueCategory.ECONOMY, "청년 고용과 자동화 논쟁", "반복 사무직은 자동화 압박을 받지만 데이터 분석, AI 운영, 산업별 컨설팅 직무는 성장 가능성이 있습니다.", 66),
                new Seed(IssueCategory.CULTURE, "K-콘텐츠 글로벌 확산", "콘텐츠 제작, 번역, 마케팅, IP 관리 직무가 AI 도구와 결합해 새로운 업무 형태로 확장되고 있습니다.", 49),
                new Seed(IssueCategory.DISEASE, "계절성 감염병 모니터링", "보건 데이터, 병원 운영, 원격 진료 관련 업무의 디지털화가 계속 진행되고 있습니다.", 45),
                new Seed(IssueCategory.AI_JOBS, "사무 자동화와 AI 협업 직무 증가", "문서 작성, 리서치, 고객 응대는 자동화되지만 AI를 활용해 의사결정하는 직무는 더 중요해지고 있습니다.", 78)
        ));
        addCountryIssues(items, countryService.findByCodeOrDefault("US"), List.of(
                new Seed(IssueCategory.NEWS, "빅테크 AI 경쟁 심화", "클라우드, 생성형 AI, 반도체 생태계가 빠르게 성장하며 고급 기술 인력 수요가 높아지고 있습니다.", 75),
                new Seed(IssueCategory.POLITICS, "AI 규제와 저작권 논쟁", "AI 학습 데이터, 저작권, 노동시장 보호를 둘러싼 정책 변화가 기업 운영에 영향을 줄 수 있습니다.", 69),
                new Seed(IssueCategory.ECONOMY, "화이트칼라 업무 재편", "회계, 마케팅, 법무, 고객지원의 초안 작성 업무가 자동화되면서 직무 설계가 바뀌고 있습니다.", 82),
                new Seed(IssueCategory.WAR, "국제 안보와 공급망 리스크", "방산, 사이버보안, 공급망 분석 분야에서 전문 인력 수요가 늘어날 가능성이 있습니다.", 61),
                new Seed(IssueCategory.AI_JOBS, "AI 에이전트 도입 확대", "반복 업무를 처리하는 AI 에이전트가 확산되며 인간은 검수, 전략, 고객 관계 업무에 집중하게 됩니다.", 85)
        ));
        addCountryIssues(items, countryService.findByCodeOrDefault("JP"), List.of(
                new Seed(IssueCategory.ECONOMY, "고령화와 돌봄 인력 부족", "간호, 돌봄, 로봇 보조 서비스가 함께 성장하며 헬스케어 직업 구조가 변화하고 있습니다.", 70),
                new Seed(IssueCategory.CULTURE, "콘텐츠 IP와 게임 산업 확장", "애니메이션, 게임, 캐릭터 IP 관리에서 AI 번역·제작 도구 활용이 늘고 있습니다.", 52),
                new Seed(IssueCategory.AI_JOBS, "제조 자동화 고도화", "공장 자동화와 품질 검사 AI가 확대되면서 현장 기술자에게 데이터 이해력이 요구됩니다.", 73)
        ));
        addCountryIssues(items, countryService.findByCodeOrDefault("DE"), List.of(
                new Seed(IssueCategory.ECONOMY, "제조업 디지털 전환", "스마트팩토리와 산업 데이터 분석 역량이 자동차·기계 산업의 경쟁력을 좌우하고 있습니다.", 64),
                new Seed(IssueCategory.POLITICS, "EU AI 규제 대응", "기업은 AI 리스크 관리, 투명성, 데이터 거버넌스 인력을 더 많이 필요로 할 수 있습니다.", 57),
                new Seed(IssueCategory.AI_JOBS, "엔지니어링 업무의 AI 보조", "설계 초안과 시뮬레이션은 AI가 돕고, 인간 엔지니어는 검증과 시스템 판단을 맡게 됩니다.", 62)
        ));
        addCountryIssues(items, countryService.findByCodeOrDefault("IN"), List.of(
                new Seed(IssueCategory.ECONOMY, "디지털 서비스 수출 확대", "IT 서비스, 데이터 운영, 글로벌 백오피스 업무가 AI와 결합해 고부가가치 업무로 이동하고 있습니다.", 76),
                new Seed(IssueCategory.DISEASE, "대규모 보건 데이터 인프라", "공공 보건 데이터와 원격 의료 서비스가 의료 접근성 개선과 직업 수요 변화를 만들고 있습니다.", 55),
                new Seed(IssueCategory.AI_JOBS, "AI 교육·재교육 시장 성장", "대규모 인력 재교육 수요가 커지며 AI 튜터, 커리큘럼 설계, 직업 전환 코치가 성장할 수 있습니다.", 80)
        ));
        addCountryIssues(items, countryService.findByCodeOrDefault("BR"), List.of(
                new Seed(IssueCategory.ECONOMY, "농업·자원 산업 데이터화", "기후, 물류, 원자재 가격 데이터를 활용하는 농업 기술과 리스크 분석 직무가 성장하고 있습니다.", 59),
                new Seed(IssueCategory.CULTURE, "크리에이터 경제 확대", "영상·음악·소셜 콘텐츠 시장에서 AI 편집과 현지화 역량이 중요해지고 있습니다.", 47),
                new Seed(IssueCategory.AI_JOBS, "서비스업 자동화 확대", "콜센터, 예약, 행정 업무 자동화가 빠르게 진행되며 고객 경험 설계 역량이 중요해집니다.", 68)
        ));
        return items;
    }

    private void addCountryIssues(List<CountryIssue> items, Country country, List<Seed> seeds) {
        for (int i = 0; i < seeds.size(); i++) {
            Seed seed = seeds.get(i);
            items.add(new CountryIssue(
                    UUID.randomUUID().toString(),
                    country.code(),
                    country.name(),
                    seed.category,
                    seed.title,
                    seed.summary,
                    "https://example.com/source/" + country.code().toLowerCase() + "/" + seed.category.name().toLowerCase(),
                    seed.riskScore,
                    country.latitude(),
                    country.longitude(),
                    Instant.now().minus(i + 1L, ChronoUnit.HOURS)
            ));
        }
    }

    private record Seed(IssueCategory category, String title, String summary, int riskScore) {}
}

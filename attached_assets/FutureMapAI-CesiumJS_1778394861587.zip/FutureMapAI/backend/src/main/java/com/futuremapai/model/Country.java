package com.futuremapai.model;

public record Country(
        String code,
        String name,
        String region,
        double latitude,
        double longitude,
        int aiJobRiskScore
) {}

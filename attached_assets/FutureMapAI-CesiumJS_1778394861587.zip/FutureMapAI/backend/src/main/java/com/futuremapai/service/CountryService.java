package com.futuremapai.service;

import com.futuremapai.model.Country;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
public class CountryService {
    private final List<Country> countries = List.of(
            new Country("KR", "대한민국", "Asia", 36.5, 127.8, 67),
            new Country("US", "미국", "North America", 39.8, -98.6, 72),
            new Country("JP", "일본", "Asia", 36.2, 138.2, 61),
            new Country("DE", "독일", "Europe", 51.2, 10.4, 58),
            new Country("IN", "인도", "Asia", 20.6, 78.9, 74),
            new Country("BR", "브라질", "South America", -14.2, -51.9, 55)
    );

    public List<Country> findAll() {
        return countries;
    }

    public Country findByCodeOrDefault(String code) {
        return findByCode(code).orElse(countries.get(0));
    }

    public Optional<Country> findByCode(String code) {
        return countries.stream()
                .filter(country -> country.code().equalsIgnoreCase(code))
                .findFirst();
    }

    public Map<String, String> countryNameMap() {
        return Map.of(
                "KR", "대한민국",
                "US", "미국",
                "JP", "일본",
                "DE", "독일",
                "IN", "인도",
                "BR", "브라질"
        );
    }
}

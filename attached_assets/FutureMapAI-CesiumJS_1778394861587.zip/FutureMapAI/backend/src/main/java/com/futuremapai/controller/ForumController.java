package com.futuremapai.controller;

import com.futuremapai.dto.CreateForumPostRequest;
import com.futuremapai.model.ForumPost;
import com.futuremapai.service.ForumService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/forum/posts")
public class ForumController {
    private final ForumService forumService;

    public ForumController(ForumService forumService) {
        this.forumService = forumService;
    }

    @GetMapping
    public List<ForumPost> posts(
            @RequestParam(defaultValue = "KR") String country,
            @RequestParam(required = false) String job
    ) {
        return forumService.findPosts(country, job);
    }

    @PostMapping
    public ForumPost create(@Valid @RequestBody CreateForumPostRequest request) {
        return forumService.createPost(request);
    }
}

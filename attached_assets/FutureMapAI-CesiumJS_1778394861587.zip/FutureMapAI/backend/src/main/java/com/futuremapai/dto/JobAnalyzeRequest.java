package com.futuremapai.dto;

import jakarta.validation.constraints.NotBlank;

public record JobAnalyzeRequest(
        @NotBlank String countryCode,
        @NotBlank String jobName
) {}

package com.futuremapai.controller;

import com.futuremapai.model.CountryIssue;
import com.futuremapai.model.IssueCategory;
import com.futuremapai.service.IssueService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/issues")
public class IssueController {
    private final IssueService issueService;

    public IssueController(IssueService issueService) {
        this.issueService = issueService;
    }

    @GetMapping
    public List<CountryIssue> getIssues(
            @RequestParam(defaultValue = "KR") String country,
            @RequestParam(required = false) String layers
    ) {
        List<IssueCategory> categories = parseLayers(layers);
        return issueService.findIssues(country, categories);
    }

    private List<IssueCategory> parseLayers(String layers) {
        if (layers == null || layers.isBlank()) {
            return Arrays.asList(IssueCategory.values());
        }
        return Arrays.stream(layers.split(","))
                .map(String::trim)
                .filter(value -> !value.isBlank())
                .map(IssueCategory::valueOf)
                .toList();
    }
}

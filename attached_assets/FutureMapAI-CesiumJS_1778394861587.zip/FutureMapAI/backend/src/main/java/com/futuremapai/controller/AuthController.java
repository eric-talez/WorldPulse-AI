package com.futuremapai.controller;

import com.futuremapai.dto.LoginRequest;
import com.futuremapai.dto.LoginResponse;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.UUID;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    @PostMapping("/login")
    public LoginResponse login(@Valid @RequestBody LoginRequest request) {
        // MVP mock login. 실제 서비스에서는 password hash 검증 + JWT 발급으로 교체하세요.
        return new LoginResponse("mock-token-" + UUID.randomUUID(), request.email(), "FREE");
    }
}

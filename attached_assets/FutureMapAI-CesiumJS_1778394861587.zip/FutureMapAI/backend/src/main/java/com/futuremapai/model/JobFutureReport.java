package com.futuremapai.model;

import java.time.Instant;
import java.util.List;

public record JobFutureReport(
        String id,
        String countryCode,
        String countryName,
        String jobName,
        int automationRisk,
        int growthScore,
        String aiImpactSummary,
        List<String> automatedTasks,
        List<String> humanStrengths,
        List<String> futureChanges,
        List<String> recommendedSkills,
        List<String> countryOpportunities,
        Instant createdAt
) {}

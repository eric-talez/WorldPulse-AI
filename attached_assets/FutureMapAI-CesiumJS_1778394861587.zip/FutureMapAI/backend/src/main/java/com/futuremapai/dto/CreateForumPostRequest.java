package com.futuremapai.dto;

import jakarta.validation.constraints.NotBlank;

public record CreateForumPostRequest(
        @NotBlank String countryCode,
        @NotBlank String jobName,
        @NotBlank String author,
        @NotBlank String title,
        @NotBlank String body
) {}

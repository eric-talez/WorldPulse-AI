package com.futuremapai.service;

import com.futuremapai.model.Country;
import com.futuremapai.model.JobFutureReport;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

@Service
public class JobAnalysisService {
    private final CountryService countryService;

    public JobAnalysisService(CountryService countryService) {
        this.countryService = countryService;
    }

    public JobFutureReport analyze(String countryCode, String jobName) {
        Country country = countryService.findByCodeOrDefault(countryCode);
        JobProfile profile = classify(jobName);

        String summary = String.format(
                "%s에서 '%s' 직업은 단순 반복 업무는 AI로 빠르게 자동화될 수 있지만, 고객 설득, 전략 판단, 윤리적 책임, 현장 맥락 이해가 필요한 업무는 계속 인간 중심으로 남을 가능성이 큽니다.",
                country.name(), jobName
        );

        return new JobFutureReport(
                UUID.randomUUID().toString(),
                country.code(),
                country.name(),
                jobName,
                adjustByCountry(profile.automationRisk(), country.aiJobRiskScore()),
                adjustGrowth(profile.growthScore(), country.aiJobRiskScore()),
                summary,
                profile.automatedTasks(),
                profile.humanStrengths(),
                profile.futureChanges(),
                profile.recommendedSkills(),
                countryOpportunities(country, jobName),
                Instant.now()
        );
    }

    private JobProfile classify(String jobName) {
        String normalized = jobName.toLowerCase(Locale.ROOT);

        if (containsAny(normalized, "세무", "회계", "account", "tax", "bookkeeping")) {
            return new JobProfile(
                    82,
                    69,
                    List.of("장부 분류", "신고서 초안 작성", "증빙 자료 정리", "반복적인 세무 질의 응답"),
                    List.of("절세 전략 설계", "세무조사 대응", "고객 상황별 상담", "법 해석과 리스크 판단"),
                    List.of("단순 신고 대행에서 AI 세무 컨설팅으로 이동", "고객 데이터 기반 맞춤형 절세 리포트 수요 증가", "AI 결과를 검수하는 책임자 역할 강화"),
                    List.of("AI 세무 소프트웨어 활용", "데이터 분석", "법률 해석", "고객 커뮤니케이션", "산업별 세무 전문성")
            );
        }

        if (containsAny(normalized, "개발", "software", "developer", "engineer", "programmer")) {
            return new JobProfile(
                    65,
                    86,
                    List.of("보일러플레이트 코드 작성", "기본 테스트 코드 생성", "문서화 초안", "간단한 버그 수정 제안"),
                    List.of("시스템 설계", "요구사항 해석", "보안·성능 판단", "팀 커뮤니케이션"),
                    List.of("코딩 자체보다 문제 정의와 아키텍처 역량이 중요", "AI 코파일럿을 활용한 생산성 격차 확대", "도메인 지식이 있는 개발자 가치 상승"),
                    List.of("AI 코딩 도구 활용", "시스템 디자인", "클라우드", "데이터베이스", "보안", "제품 감각")
            );
        }

        if (containsAny(normalized, "간호", "nurse", "health", "medical")) {
            return new JobProfile(
                    38,
                    82,
                    List.of("기록 정리", "기초 문진 요약", "스케줄링", "일부 환자 교육 자료 작성"),
                    List.of("환자 케어", "응급 판단", "공감과 커뮤니케이션", "윤리적 책임"),
                    List.of("AI가 문서 업무를 줄이고 직접 환자 케어 시간이 늘어남", "원격의료와 데이터 기반 케어 코디네이션 확대", "고령화로 수요는 계속 증가"),
                    List.of("전자차트 활용", "환자 커뮤니케이션", "헬스 데이터 이해", "원격의료 도구", "전문 분야 자격")
            );
        }

        if (containsAny(normalized, "마케팅", "marketing", "designer", "디자이너", "content", "creator")) {
            return new JobProfile(
                    58,
                    78,
                    List.of("카피 초안", "이미지 시안", "광고 문구 A/B 초안", "기초 리서치"),
                    List.of("브랜드 전략", "소비자 심리 해석", "창의적 방향성", "클라이언트 설득"),
                    List.of("제작 속도는 빨라지고 차별화된 컨셉 기획이 더 중요", "AI로 개인화 마케팅이 확대", "데이터 기반 크리에이티브 직무 성장"),
                    List.of("프롬프트 설계", "브랜드 전략", "데이터 분석", "콘텐츠 실험", "고객 인사이트")
            );
        }

        return new JobProfile(
                60,
                70,
                List.of("반복 문서 작업", "기초 리서치", "요약과 초안 작성", "단순 고객 응대"),
                List.of("전략 판단", "복잡한 의사소통", "윤리적 책임", "현장 맥락 이해"),
                List.of("반복 업무는 줄고 AI를 관리·검수하는 역할이 증가", "업무 생산성 차이가 커짐", "산업별 전문성과 AI 활용 역량의 결합이 중요"),
                List.of("AI 도구 활용", "데이터 리터러시", "문제 정의", "커뮤니케이션", "도메인 전문성")
        );
    }

    private boolean containsAny(String text, String... keywords) {
        for (String keyword : keywords) {
            if (text.contains(keyword.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    private int adjustByCountry(int base, int countryRisk) {
        return clamp(Math.round((base * 0.75f) + (countryRisk * 0.25f)));
    }

    private int adjustGrowth(int base, int countryRisk) {
        return clamp(Math.round((base * 0.8f) + ((100 - Math.abs(65 - countryRisk)) * 0.2f)));
    }

    private int clamp(int value) {
        return Math.max(0, Math.min(100, value));
    }

    private List<String> countryOpportunities(Country country, String jobName) {
        return List.of(
                country.name() + "의 최근 이슈를 모니터링해 " + jobName + " 관련 리스크를 빠르게 파악하기",
                "AI 도구를 활용해 반복 업무 시간을 줄이고 상담·전략 업무 비중 높이기",
                "국가별 규제, 산업 변화, 문화 트렌드를 반영한 전문 리포트 만들기"
        );
    }

    private record JobProfile(
            int automationRisk,
            int growthScore,
            List<String> automatedTasks,
            List<String> humanStrengths,
            List<String> futureChanges,
            List<String> recommendedSkills
    ) {}
}

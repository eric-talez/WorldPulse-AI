package com.futuremapai.controller;

import com.futuremapai.dto.JobAnalyzeRequest;
import com.futuremapai.model.JobFutureReport;
import com.futuremapai.service.JobAnalysisService;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/job-reports")
public class JobReportController {
    private final JobAnalysisService jobAnalysisService;

    public JobReportController(JobAnalysisService jobAnalysisService) {
        this.jobAnalysisService = jobAnalysisService;
    }

    @PostMapping("/analyze")
    public JobFutureReport analyze(@Valid @RequestBody JobAnalyzeRequest request) {
        return jobAnalysisService.analyze(request.countryCode(), request.jobName());
    }
}

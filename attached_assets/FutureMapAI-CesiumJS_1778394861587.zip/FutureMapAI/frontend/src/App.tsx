import { useEffect, useMemo, useState } from 'react';
import { Header } from './components/Header';
import { LayerControls } from './components/LayerControls';
import { WorldMap } from './components/WorldMap';
import { CountryPanel } from './components/CountryPanel';
import { JobReportForm } from './components/JobReportForm';
import { ForumBoard } from './components/ForumBoard';
import { LoginCard } from './components/LoginCard';
import { api } from './api/client';
import { ALL_CATEGORIES } from './data/categories';
import type { Country, CountryIssue, IssueCategory, JobFutureReport } from './types';

export default function App() {
  const [countries, setCountries] = useState<Country[]>([]);
  const [selectedCountryCode, setSelectedCountryCode] = useState('KR');
  const [activeLayers, setActiveLayers] = useState<IssueCategory[]>(ALL_CATEGORIES);
  const [issues, setIssues] = useState<CountryIssue[]>([]);
  const [loadingIssues, setLoadingIssues] = useState(false);
  const [latestReport, setLatestReport] = useState<JobFutureReport | null>(null);

  useEffect(() => {
    api.getCountries().then((items) => {
      setCountries(items);
      if (!items.some((country) => country.code === selectedCountryCode) && items.length > 0) {
        setSelectedCountryCode(items[0].code);
      }
    });
  }, []);

  useEffect(() => {
    setLoadingIssues(true);
    api
      .getIssues(selectedCountryCode, activeLayers)
      .then(setIssues)
      .catch(() => setIssues([]))
      .finally(() => setLoadingIssues(false));
  }, [selectedCountryCode, activeLayers]);

  const selectedCountry = useMemo(
    () => countries.find((country) => country.code === selectedCountryCode),
    [countries, selectedCountryCode]
  );

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <Header selectedCountryName={selectedCountry?.name} />

      <main className="mx-auto grid max-w-7xl gap-6 px-5 py-6 xl:grid-cols-[280px_1fr_380px]">
        <div className="space-y-6">
          <LayerControls activeLayers={activeLayers} onChange={setActiveLayers} />
          <LoginCard />
        </div>

        <div className="space-y-6">
          <WorldMap
            countries={countries}
            issues={issues}
            selectedCountryCode={selectedCountryCode}
            onSelectCountry={(code) => {
              setSelectedCountryCode(code);
              setLatestReport(null);
            }}
          />
          <JobReportForm country={selectedCountry} onReportCreated={setLatestReport} />
          <ForumBoard country={selectedCountry} latestReport={latestReport} />
        </div>

        <CountryPanel country={selectedCountry} issues={issues} loading={loadingIssues} />
      </main>
    </div>
  );
}

import type { Country, CountryIssue, ForumPost, IssueCategory, JobFutureReport } from '../types';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? 'http://localhost:8080/api';

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      'Content-Type': 'application/json',
      ...(options?.headers ?? {})
    },
    ...options
  });

  if (!response.ok) {
    const message = await response.text();
    throw new Error(message || `Request failed: ${response.status}`);
  }

  return response.json() as Promise<T>;
}

export const api = {
  getCountries() {
    return request<Country[]>('/countries');
  },

  getIssues(countryCode: string, layers: IssueCategory[]) {
    const params = new URLSearchParams();
    params.set('country', countryCode);
    if (layers.length > 0) params.set('layers', layers.join(','));
    return request<CountryIssue[]>(`/issues?${params.toString()}`);
  },

  analyzeJob(countryCode: string, jobName: string) {
    return request<JobFutureReport>('/job-reports/analyze', {
      method: 'POST',
      body: JSON.stringify({ countryCode, jobName })
    });
  },

  getForumPosts(countryCode: string, jobName?: string) {
    const params = new URLSearchParams();
    params.set('country', countryCode);
    if (jobName) params.set('job', jobName);
    return request<ForumPost[]>(`/forum/posts?${params.toString()}`);
  },

  createForumPost(payload: Pick<ForumPost, 'countryCode' | 'jobName' | 'author' | 'title' | 'body'>) {
    return request<ForumPost>('/forum/posts', {
      method: 'POST',
      body: JSON.stringify(payload)
    });
  }
};

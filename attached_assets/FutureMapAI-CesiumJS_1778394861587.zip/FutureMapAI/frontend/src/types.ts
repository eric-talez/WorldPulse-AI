export type IssueCategory =
  | 'NEWS'
  | 'WAR'
  | 'DISEASE'
  | 'POLITICS'
  | 'ECONOMY'
  | 'CULTURE'
  | 'AI_JOBS';

export interface Country {
  code: string;
  name: string;
  region: string;
  latitude: number;
  longitude: number;
  aiJobRiskScore: number;
}

export interface CountryIssue {
  id: string;
  countryCode: string;
  countryName: string;
  category: IssueCategory;
  title: string;
  summary: string;
  sourceUrl: string;
  riskScore: number;
  latitude: number;
  longitude: number;
  createdAt: string;
}

export interface JobFutureReport {
  id: string;
  countryCode: string;
  countryName: string;
  jobName: string;
  automationRisk: number;
  growthScore: number;
  aiImpactSummary: string;
  automatedTasks: string[];
  humanStrengths: string[];
  futureChanges: string[];
  recommendedSkills: string[];
  countryOpportunities: string[];
  createdAt: string;
}

export interface ForumPost {
  id: string;
  countryCode: string;
  jobName: string;
  author: string;
  title: string;
  body: string;
  likes: number;
  createdAt: string;
}

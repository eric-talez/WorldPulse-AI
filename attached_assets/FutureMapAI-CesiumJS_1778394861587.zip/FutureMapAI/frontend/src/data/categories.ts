import type { IssueCategory } from '../types';

export const CATEGORY_LABELS: Record<IssueCategory, string> = {
  NEWS: '뉴스',
  WAR: '전쟁/분쟁',
  DISEASE: '질병',
  POLITICS: '정치',
  ECONOMY: '경제',
  CULTURE: '문화',
  AI_JOBS: 'AI 직업 변화'
};

export const CATEGORY_DESCRIPTIONS: Record<IssueCategory, string> = {
  NEWS: '국가별 주요 뉴스와 사회 이슈',
  WAR: '무력 충돌, 시위, 긴장 지역',
  DISEASE: '감염병, 보건 이슈, WHO 알림',
  POLITICS: '선거, 법안, 외교, 정권 변화',
  ECONOMY: '환율, 실업률, 산업 변화',
  CULTURE: '문화 콘텐츠, 종교, 사회 트렌드',
  AI_JOBS: '국가별 직업 자동화 및 성장 변화'
};

export const ALL_CATEGORIES = Object.keys(CATEGORY_LABELS) as IssueCategory[];

import type { IssueCategory } from '../types';
import { ALL_CATEGORIES, CATEGORY_DESCRIPTIONS, CATEGORY_LABELS } from '../data/categories';

interface LayerControlsProps {
  activeLayers: IssueCategory[];
  onChange: (layers: IssueCategory[]) => void;
}

export function LayerControls({ activeLayers, onChange }: LayerControlsProps) {
  function toggle(category: IssueCategory) {
    if (activeLayers.includes(category)) {
      onChange(activeLayers.filter((item) => item !== category));
    } else {
      onChange([...activeLayers, category]);
    }
  }

  return (
    <section className="rounded-3xl border border-white/10 bg-slate-900/80 p-4 shadow-2xl shadow-black/20">
      <div className="mb-4 flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white">지도 레이어</h2>
          <p className="text-xs text-slate-400">보고 싶은 글로벌 이슈를 선택하세요.</p>
        </div>
        <button
          className="rounded-full bg-slate-800 px-3 py-1 text-xs text-slate-200 transition hover:bg-slate-700"
          onClick={() => onChange(ALL_CATEGORIES)}
        >
          전체 선택
        </button>
      </div>

      <div className="grid gap-2">
        {ALL_CATEGORIES.map((category) => {
          const selected = activeLayers.includes(category);
          return (
            <button
              key={category}
              onClick={() => toggle(category)}
              className={`rounded-2xl border p-3 text-left transition ${
                selected
                  ? 'border-blue-400/50 bg-blue-500/15 text-white'
                  : 'border-white/10 bg-white/5 text-slate-300 hover:bg-white/10'
              }`}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-semibold">{CATEGORY_LABELS[category]}</span>
                <span className={`h-3 w-3 rounded-full ${selected ? 'bg-blue-400' : 'bg-slate-600'}`} />
              </div>
              <p className="mt-1 text-xs text-slate-400">{CATEGORY_DESCRIPTIONS[category]}</p>
            </button>
          );
        })}
      </div>
    </section>
  );
}

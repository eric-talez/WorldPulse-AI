import { LockKeyhole } from 'lucide-react';

export function LoginCard() {
  return (
    <section className="rounded-3xl border border-white/10 bg-slate-900/80 p-5 shadow-2xl shadow-black/20">
      <div className="mb-4 flex items-center gap-3">
        <div className="rounded-2xl bg-white/10 p-3">
          <LockKeyhole className="h-5 w-5 text-white" />
        </div>
        <div>
          <h2 className="text-lg font-bold text-white">Mock Login</h2>
          <p className="text-sm text-slate-400">실제 서비스에서는 이메일/소셜 로그인을 연결합니다.</p>
        </div>
      </div>
      <div className="grid gap-2">
        <input className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-white outline-none" placeholder="email@example.com" />
        <input className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-white outline-none" placeholder="password" type="password" />
        <button className="rounded-2xl bg-white px-4 py-3 font-bold text-slate-950">로그인</button>
      </div>
    </section>
  );
}

import { FormEvent, useEffect, useState } from 'react';
import { MessageCircle, Plus, Send } from 'lucide-react';
import type { Country, ForumPost, JobFutureReport } from '../types';
import { api } from '../api/client';

interface ForumBoardProps {
  country?: Country;
  latestReport?: JobFutureReport | null;
}

export function ForumBoard({ country, latestReport }: ForumBoardProps) {
  const [posts, setPosts] = useState<ForumPost[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [title, setTitle] = useState('이 직업의 미래가 어떻게 바뀔까요?');
  const [body, setBody] = useState('제가 보기에는 AI 도구를 잘 쓰는 사람이 더 유리해질 것 같습니다. 다른 분들은 어떻게 생각하시나요?');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!country) return;
    api.getForumPosts(country.code, latestReport?.jobName).then(setPosts).catch(() => setPosts([]));
  }, [country, latestReport?.jobName]);

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!country) return;
    setLoading(true);
    try {
      const created = await api.createForumPost({
        countryCode: country.code,
        jobName: latestReport?.jobName ?? 'General',
        author: 'demo-user',
        title,
        body
      });
      setPosts((prev) => [created, ...prev]);
      setShowForm(false);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="rounded-3xl border border-white/10 bg-slate-900/80 p-5 shadow-2xl shadow-black/20">
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-emerald-300">Community</p>
          <h2 className="mt-2 text-2xl font-bold text-white">국가/직업별 포럼</h2>
          <p className="mt-1 text-sm text-slate-400">같은 국가와 직업군에 관심 있는 사용자들이 토론하는 공간입니다.</p>
        </div>
        <button
          onClick={() => setShowForm((value) => !value)}
          className="inline-flex items-center gap-2 rounded-2xl bg-emerald-300 px-4 py-2 text-sm font-bold text-slate-950 transition hover:bg-emerald-200"
        >
          <Plus className="h-4 w-4" /> 글쓰기
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="mb-5 rounded-2xl border border-white/10 bg-white/5 p-4">
          <input
            value={title}
            onChange={(event) => setTitle(event.target.value)}
            className="mb-3 w-full rounded-xl border border-white/10 bg-slate-950/40 px-4 py-3 text-white outline-none placeholder:text-slate-500"
            placeholder="제목"
          />
          <textarea
            value={body}
            onChange={(event) => setBody(event.target.value)}
            className="min-h-28 w-full rounded-xl border border-white/10 bg-slate-950/40 px-4 py-3 text-white outline-none placeholder:text-slate-500"
            placeholder="내용"
          />
          <button
            disabled={loading}
            className="mt-3 inline-flex items-center gap-2 rounded-xl bg-white px-4 py-2 text-sm font-bold text-slate-950 disabled:opacity-60"
          >
            <Send className="h-4 w-4" /> 등록
          </button>
        </form>
      )}

      <div className="space-y-3">
        {posts.map((post) => (
          <article key={post.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="mb-2 flex items-center justify-between gap-3">
              <span className="inline-flex items-center gap-2 text-xs font-semibold text-emerald-200">
                <MessageCircle className="h-4 w-4" /> {post.countryCode} · {post.jobName}
              </span>
              <span className="text-xs text-slate-500">♥ {post.likes}</span>
            </div>
            <h3 className="text-sm font-bold text-white">{post.title}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-300">{post.body}</p>
            <p className="mt-3 text-xs text-slate-500">by {post.author} · {new Date(post.createdAt).toLocaleDateString()}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

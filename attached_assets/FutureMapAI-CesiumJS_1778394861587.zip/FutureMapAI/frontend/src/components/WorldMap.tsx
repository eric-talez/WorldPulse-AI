import { useEffect, useMemo, useRef } from 'react';
import {
  Cartesian2,
  Cartesian3,
  Color,
  CustomDataSource,
  EllipsoidTerrainProvider,
  Entity,
  Ion,
  LabelStyle,
  Math as CesiumMath,
  NearFarScalar,
  ScreenSpaceEventHandler,
  ScreenSpaceEventType,
  TileMapServiceImageryProvider,
  Viewer,
  VerticalOrigin,
  buildModuleUrl
} from 'cesium';
import 'cesium/Build/Cesium/Widgets/widgets.css';
import { Compass, MousePointerClick, Radar, Rotate3D, ZoomIn } from 'lucide-react';
import type { Country, CountryIssue, IssueCategory } from '../types';
import { CATEGORY_LABELS } from '../data/categories';

interface WorldMapProps {
  countries: Country[];
  issues: CountryIssue[];
  selectedCountryCode: string;
  onSelectCountry: (countryCode: string) => void;
}

function riskColor(score: number) {
  if (score >= 80) return Color.fromCssColorString('#fb7185');
  if (score >= 60) return Color.fromCssColorString('#fb923c');
  if (score >= 40) return Color.fromCssColorString('#fde047');
  return Color.fromCssColorString('#34d399');
}

function issueColor(category: IssueCategory) {
  const colors: Record<IssueCategory, Color> = {
    NEWS: Color.fromCssColorString('#60a5fa'),
    WAR: Color.fromCssColorString('#f43f5e'),
    DISEASE: Color.fromCssColorString('#a78bfa'),
    POLITICS: Color.fromCssColorString('#fbbf24'),
    ECONOMY: Color.fromCssColorString('#34d399'),
    CULTURE: Color.fromCssColorString('#f472b6'),
    AI_JOBS: Color.fromCssColorString('#22d3ee')
  };
  return colors[category];
}

function issueOffset(index: number) {
  const angle = index * 1.15;
  const radius = 0.7 + (index % 3) * 0.25;
  return {
    longitudeOffset: Math.cos(angle) * radius,
    latitudeOffset: Math.sin(angle) * radius
  };
}

export function WorldMap({ countries, issues, selectedCountryCode, onSelectCountry }: WorldMapProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const viewerRef = useRef<Viewer | null>(null);
  const countriesSourceRef = useRef<CustomDataSource | null>(null);
  const issuesSourceRef = useRef<CustomDataSource | null>(null);
  const onSelectCountryRef = useRef(onSelectCountry);
  const firstCameraMoveDoneRef = useRef(false);

  const selectedCountry = useMemo(
    () => countries.find((country) => country.code === selectedCountryCode),
    [countries, selectedCountryCode]
  );
  const selectedIssues = issues.slice(0, 6);

  useEffect(() => {
    onSelectCountryRef.current = onSelectCountry;
  }, [onSelectCountry]);

  useEffect(() => {
    if (!containerRef.current || viewerRef.current) return;

    Ion.defaultAccessToken = import.meta.env.VITE_CESIUM_ION_TOKEN ?? '';

    const viewer = new Viewer(containerRef.current, {
      animation: false,
      timeline: false,
      geocoder: false,
      homeButton: false,
      sceneModePicker: false,
      baseLayerPicker: false,
      navigationHelpButton: false,
      fullscreenButton: false,
      infoBox: false,
      selectionIndicator: false,
      terrainProvider: new EllipsoidTerrainProvider(),
      imageryProvider: false
    } as ConstructorParameters<typeof Viewer>[1]);

    viewerRef.current = viewer;
    viewer.scene.globe.enableLighting = true;
    viewer.scene.globe.baseColor = Color.fromCssColorString('#12213f');
    if (viewer.scene.skyAtmosphere) viewer.scene.skyAtmosphere.show = true;
    if (viewer.scene.sun) viewer.scene.sun.show = true;
    if (viewer.scene.moon) viewer.scene.moon.show = false;
    viewer.scene.screenSpaceCameraController.enableRotate = true;
    viewer.scene.screenSpaceCameraController.enableTranslate = true;
    viewer.scene.screenSpaceCameraController.enableZoom = true;
    viewer.scene.screenSpaceCameraController.enableTilt = true;
    viewer.scene.screenSpaceCameraController.enableLook = true;
    viewer.camera.setView({
      destination: Cartesian3.fromDegrees(126.9, 28, 25_000_000),
      orientation: {
        heading: 0,
        pitch: CesiumMath.toRadians(-90),
        roll: 0
      }
    });

    const countriesSource = new CustomDataSource('countries');
    const issuesSource = new CustomDataSource('issues');
    countriesSourceRef.current = countriesSource;
    issuesSourceRef.current = issuesSource;
    viewer.dataSources.add(countriesSource);
    viewer.dataSources.add(issuesSource);

    let destroyed = false;
    TileMapServiceImageryProvider.fromUrl(buildModuleUrl('Assets/Textures/NaturalEarthII'), {
      fileExtension: 'jpg'
    })
      .then((provider) => {
        if (!destroyed && !viewer.isDestroyed()) {
          viewer.imageryLayers.addImageryProvider(provider);
        }
      })
      .catch(() => {
        // The globe still works without imagery; this keeps the MVP usable even if local Cesium assets are missing.
      });

    const clickHandler = new ScreenSpaceEventHandler(viewer.scene.canvas);
    clickHandler.setInputAction((movement: any) => {
      const picked = viewer.scene.pick(movement.position);
      const pickedEntity = picked?.id as Entity | undefined;
      const countryCode = pickedEntity?.properties?.countryCode?.getValue(viewer.clock.currentTime);
      if (typeof countryCode === 'string') {
        onSelectCountryRef.current(countryCode);
      }
    }, ScreenSpaceEventType.LEFT_CLICK);

    return () => {
      destroyed = true;
      clickHandler.destroy();
      countriesSourceRef.current = null;
      issuesSourceRef.current = null;
      viewerRef.current = null;
      if (!viewer.isDestroyed()) viewer.destroy();
    };
  }, []);

  useEffect(() => {
    const source = countriesSourceRef.current;
    if (!source) return;

    source.entities.removeAll();
    countries.forEach((country) => {
      const selected = country.code === selectedCountryCode;
      source.entities.add({
        id: `country-${country.code}`,
        name: country.name,
        position: Cartesian3.fromDegrees(country.longitude, country.latitude, selected ? 180_000 : 90_000),
        point: {
          pixelSize: selected ? 17 : 12,
          color: riskColor(country.aiJobRiskScore),
          outlineColor: selected ? Color.WHITE : Color.fromCssColorString('#0f172a'),
          outlineWidth: selected ? 3 : 2,
          scaleByDistance: new NearFarScalar(2_000_000, 1.3, 32_000_000, 0.45)
        },
        label: {
          text: country.name,
          font: selected ? '700 15px Inter, sans-serif' : '600 13px Inter, sans-serif',
          fillColor: Color.WHITE,
          outlineColor: Color.BLACK,
          outlineWidth: 4,
          style: LabelStyle.FILL_AND_OUTLINE,
          verticalOrigin: VerticalOrigin.BOTTOM,
          pixelOffset: new Cartesian2(0, selected ? -24 : -20),
          scaleByDistance: new NearFarScalar(2_000_000, 1, 32_000_000, 0.35)
        },
        properties: {
          countryCode: country.code
        }
      });
    });
  }, [countries, selectedCountryCode]);

  useEffect(() => {
    const source = issuesSourceRef.current;
    if (!source) return;

    source.entities.removeAll();
    issues.forEach((issue, index) => {
      const offset = issueOffset(index);
      source.entities.add({
        id: `issue-${issue.id}`,
        name: issue.title,
        position: Cartesian3.fromDegrees(
          issue.longitude + offset.longitudeOffset,
          issue.latitude + offset.latitudeOffset,
          260_000 + index * 28_000
        ),
        point: {
          pixelSize: 8 + Math.min(issue.riskScore / 20, 5),
          color: issueColor(issue.category).withAlpha(0.95),
          outlineColor: Color.WHITE.withAlpha(0.8),
          outlineWidth: 1,
          scaleByDistance: new NearFarScalar(1_500_000, 1.4, 30_000_000, 0.3)
        },
        label: {
          text: CATEGORY_LABELS[issue.category],
          font: '600 11px Inter, sans-serif',
          fillColor: Color.WHITE,
          outlineColor: Color.BLACK,
          outlineWidth: 3,
          style: LabelStyle.FILL_AND_OUTLINE,
          verticalOrigin: VerticalOrigin.BOTTOM,
          pixelOffset: new Cartesian2(0, -16),
          scaleByDistance: new NearFarScalar(1_500_000, 1, 30_000_000, 0.25)
        }
      });
    });
  }, [issues]);

  useEffect(() => {
    const viewer = viewerRef.current;
    if (!viewer || !selectedCountry) return;

    viewer.camera.flyTo({
      destination: Cartesian3.fromDegrees(selectedCountry.longitude, selectedCountry.latitude, firstCameraMoveDoneRef.current ? 5_200_000 : 10_500_000),
      duration: firstCameraMoveDoneRef.current ? 1.2 : 0.8,
      orientation: {
        heading: 0,
        pitch: CesiumMath.toRadians(-75),
        roll: 0
      }
    });
    firstCameraMoveDoneRef.current = true;
  }, [selectedCountry]);

  return (
    <section className="relative min-h-[660px] overflow-hidden rounded-[2rem] border border-white/10 bg-slate-950 shadow-2xl shadow-black/30">
      <div ref={containerRef} className="absolute inset-0" />

      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_50%_45%,transparent_0%,rgba(2,6,23,0.08)_45%,rgba(2,6,23,0.72)_100%)]" />

      <div className="absolute left-5 top-5 z-10 max-w-md rounded-2xl border border-white/10 bg-black/45 p-4 shadow-xl backdrop-blur-md">
        <div className="flex items-center gap-2 text-white">
          <Radar className="h-5 w-5 text-blue-300" />
          <span className="font-semibold">3D Earth Explorer</span>
        </div>
        <p className="mt-1 text-xs leading-5 text-slate-300">
          CesiumJS 기반 3D 지구입니다. 마우스로 드래그하면 지구가 회전하고, 휠로 확대/축소하며, 국가 마커를 클릭하면 이슈와 직업 리포트가 바뀝니다.
        </p>
      </div>

      <div className="absolute right-5 top-5 z-10 hidden rounded-2xl border border-white/10 bg-black/35 p-3 text-xs text-slate-200 backdrop-blur-md md:block">
        <div className="grid gap-2">
          <span className="flex items-center gap-2"><Rotate3D className="h-4 w-4 text-blue-300" /> 드래그: 지구 회전</span>
          <span className="flex items-center gap-2"><ZoomIn className="h-4 w-4 text-emerald-300" /> 휠: 확대/축소</span>
          <span className="flex items-center gap-2"><MousePointerClick className="h-4 w-4 text-yellow-300" /> 마커 클릭: 국가 선택</span>
        </div>
      </div>

      <div className="absolute bottom-5 left-5 z-10 rounded-2xl border border-white/10 bg-black/40 px-4 py-3 backdrop-blur-md">
        <div className="flex items-center gap-2 text-sm font-semibold text-white">
          <Compass className="h-4 w-4 text-blue-300" />
          선택 국가: {selectedCountry?.name ?? '국가 선택'}
        </div>
        <p className="mt-1 text-xs text-slate-400">Risk score가 높을수록 마커 색상이 빨강에 가까워집니다.</p>
      </div>

      <div className="absolute bottom-5 right-5 z-10 hidden max-w-3xl grid-cols-3 gap-3 xl:grid">
        {selectedIssues.map((issue) => (
          <article key={issue.id} className="rounded-2xl border border-white/10 bg-slate-950/80 p-3 backdrop-blur-md">
            <div className="mb-2 flex items-center justify-between gap-3">
              <span className="rounded-full bg-blue-400/10 px-2 py-1 text-[11px] font-semibold text-blue-200">
                {CATEGORY_LABELS[issue.category]}
              </span>
              <span className="text-[11px] text-slate-400">Risk {issue.riskScore}</span>
            </div>
            <h3 className="line-clamp-1 text-sm font-bold text-white">{issue.title}</h3>
            <p className="mt-1 line-clamp-2 text-xs text-slate-400">{issue.summary}</p>
          </article>
        ))}
      </div>
    </section>
  );
}

import { FormEvent, useState } from 'react';
import { Brain, CheckCircle2, Loader2, TrendingUp } from 'lucide-react';
import type { Country, JobFutureReport } from '../types';
import { api } from '../api/client';

interface JobReportFormProps {
  country?: Country;
  onReportCreated?: (report: JobFutureReport) => void;
}

export function JobReportForm({ country, onReportCreated }: JobReportFormProps) {
  const [jobName, setJobName] = useState('세무사');
  const [report, setReport] = useState<JobFutureReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    if (!country || !jobName.trim()) return;
    setLoading(true);
    setError('');
    try {
      const result = await api.analyzeJob(country.code, jobName.trim());
      setReport(result);
      onReportCreated?.(result);
    } catch (err) {
      setError(err instanceof Error ? err.message : '리포트를 생성하지 못했습니다.');
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="rounded-3xl border border-white/10 bg-slate-900/80 p-5 shadow-2xl shadow-black/20">
      <div className="mb-5 flex items-start justify-between gap-4">
        <div>
          <p className="text-xs uppercase tracking-[0.3em] text-orange-300">AI Job Report</p>
          <h2 className="mt-2 text-2xl font-bold text-white">직업 미래 리포트</h2>
          <p className="mt-1 text-sm text-slate-400">국가와 직업을 기반으로 자동화 위험도, 성장 가능성, 추천 역량을 분석합니다.</p>
        </div>
        <Brain className="h-9 w-9 text-orange-300" />
      </div>

      <form onSubmit={handleSubmit} className="grid gap-3 md:grid-cols-[1fr_auto]">
        <input
          value={jobName}
          onChange={(event) => setJobName(event.target.value)}
          placeholder="예: 세무사, 마케터, 간호사, 개발자"
          className="rounded-2xl border border-white/10 bg-white/5 px-4 py-3 text-white outline-none ring-blue-500/30 placeholder:text-slate-500 focus:ring-4"
        />
        <button
          disabled={loading || !country}
          className="inline-flex items-center justify-center gap-2 rounded-2xl bg-orange-400 px-5 py-3 font-bold text-slate-950 transition hover:bg-orange-300 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <TrendingUp className="h-4 w-4" />}
          분석하기
        </button>
      </form>

      {error && <p className="mt-3 rounded-2xl bg-red-500/10 p-3 text-sm text-red-200">{error}</p>}

      {report && (
        <div className="mt-5 space-y-4">
          <div className="rounded-3xl border border-orange-300/20 bg-orange-400/10 p-5">
            <div className="mb-4 flex items-center justify-between gap-4">
              <div>
                <h3 className="text-xl font-bold text-white">{report.countryName} · {report.jobName}</h3>
                <p className="mt-1 text-sm leading-6 text-slate-300">{report.aiImpactSummary}</p>
              </div>
              <CheckCircle2 className="h-8 w-8 text-emerald-300" />
            </div>
            <div className="grid gap-3 md:grid-cols-2">
              <Metric label="자동화 위험도" value={report.automationRisk} />
              <Metric label="성장 가능성" value={report.growthScore} />
            </div>
          </div>

          <ReportList title="AI로 대체되기 쉬운 업무" items={report.automatedTasks} />
          <ReportList title="인간이 강한 업무" items={report.humanStrengths} />
          <ReportList title="미래 변화 방향" items={report.futureChanges} />
          <ReportList title="추천 역량" items={report.recommendedSkills} />
          <ReportList title="국가별 기회" items={report.countryOpportunities} />
        </div>
      )}
    </section>
  );
}

function Metric({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-2xl bg-slate-950/50 p-4">
      <div className="mb-2 flex items-center justify-between text-sm">
        <span className="text-slate-300">{label}</span>
        <span className="font-bold text-white">{value}%</span>
      </div>
      <div className="h-2 overflow-hidden rounded-full bg-slate-800">
        <div className="h-full rounded-full bg-orange-300" style={{ width: `${value}%` }} />
      </div>
    </div>
  );
}

function ReportList({ title, items }: { title: string; items: string[] }) {
  return (
    <div className="rounded-2xl border border-white/10 bg-white/5 p-4">
      <h4 className="mb-3 text-sm font-bold text-white">{title}</h4>
      <ul className="space-y-2">
        {items.map((item) => (
          <li key={item} className="flex gap-2 text-sm leading-6 text-slate-300">
            <span className="mt-2 h-1.5 w-1.5 shrink-0 rounded-full bg-blue-300" />
            <span>{item}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

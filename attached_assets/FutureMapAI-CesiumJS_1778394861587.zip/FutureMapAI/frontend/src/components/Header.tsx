import { Globe2, Sparkles } from 'lucide-react';

interface HeaderProps {
  selectedCountryName?: string;
}

export function Header({ selectedCountryName }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 border-b border-white/10 bg-slate-950/85 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-blue-500 shadow-lg shadow-blue-500/30">
            <Globe2 className="h-6 w-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white">FutureMap AI</h1>
            <p className="text-xs text-slate-300">세계 변화가 내 직업을 어떻게 바꾸는지 보여주는 AI 지도</p>
          </div>
        </div>

        <div className="hidden items-center gap-3 md:flex">
          <span className="rounded-full border border-blue-400/30 bg-blue-400/10 px-4 py-2 text-sm text-blue-100">
            현재 선택: {selectedCountryName ?? '국가 선택'}
          </span>
          <button className="inline-flex items-center gap-2 rounded-full bg-white px-4 py-2 text-sm font-semibold text-slate-900 transition hover:bg-blue-50">
            <Sparkles className="h-4 w-4" />
            Pro 리포트 보기
          </button>
        </div>
      </div>
    </header>
  );
}

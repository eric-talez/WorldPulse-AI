import { AlertTriangle, BriefcaseBusiness, ExternalLink } from 'lucide-react';
import type { Country, CountryIssue } from '../types';
import { CATEGORY_LABELS } from '../data/categories';
import { StatCard } from './StatCard';

interface CountryPanelProps {
  country?: Country;
  issues: CountryIssue[];
  loading: boolean;
}

export function CountryPanel({ country, issues, loading }: CountryPanelProps) {
  const averageRisk = issues.length
    ? Math.round(issues.reduce((sum, issue) => sum + issue.riskScore, 0) / issues.length)
    : 0;

  return (
    <aside className="rounded-3xl border border-white/10 bg-slate-900/80 p-5 shadow-2xl shadow-black/20">
      <div className="mb-5">
        <p className="text-xs uppercase tracking-[0.3em] text-blue-300">Country Briefing</p>
        <h2 className="mt-2 text-2xl font-bold text-white">{country?.name ?? '국가 선택'}</h2>
        <p className="mt-1 text-sm text-slate-400">현재 이슈 요약, AI 직업 변화, 성장 가능성을 확인합니다.</p>
      </div>

      <div className="mb-5 grid grid-cols-2 gap-3">
        <StatCard label="이슈 수" value={issues.length} caption="선택한 레이어 기준" />
        <StatCard label="평균 위험도" value={averageRisk} caption="0 낮음 · 100 높음" />
      </div>

      <div className="space-y-3">
        {loading && <p className="rounded-2xl bg-white/5 p-4 text-sm text-slate-300">이슈를 불러오는 중입니다...</p>}
        {!loading && issues.length === 0 && (
          <p className="rounded-2xl bg-white/5 p-4 text-sm text-slate-300">선택한 레이어에 해당하는 이슈가 없습니다.</p>
        )}

        {issues.map((issue) => (
          <article key={issue.id} className="rounded-2xl border border-white/10 bg-white/5 p-4">
            <div className="mb-2 flex items-center justify-between gap-3">
              <span className="rounded-full bg-slate-800 px-2 py-1 text-xs font-semibold text-slate-200">
                {CATEGORY_LABELS[issue.category]}
              </span>
              <span className="inline-flex items-center gap-1 text-xs text-orange-200">
                <AlertTriangle className="h-3 w-3" />
                {issue.riskScore}
              </span>
            </div>
            <h3 className="text-sm font-bold text-white">{issue.title}</h3>
            <p className="mt-2 text-sm leading-6 text-slate-300">{issue.summary}</p>
            <a
              href={issue.sourceUrl}
              target="_blank"
              rel="noreferrer"
              className="mt-3 inline-flex items-center gap-1 text-xs font-semibold text-blue-300 hover:text-blue-200"
            >
              source 보기 <ExternalLink className="h-3 w-3" />
            </a>
          </article>
        ))}
      </div>

      <div className="mt-5 rounded-2xl border border-blue-300/20 bg-blue-500/10 p-4">
        <div className="flex items-center gap-2 text-blue-100">
          <BriefcaseBusiness className="h-4 w-4" />
          <span className="text-sm font-bold">AI 직업 변화 포인트</span>
        </div>
        <p className="mt-2 text-sm leading-6 text-blue-100/80">
          이슈 위험도와 산업 변화 데이터를 결합해 국가별 자동화 위험, 성장 직군, 필요한 역량을 분석하는 구조입니다.
        </p>
      </div>
    </aside>
  );
}

/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        night: '#0f172a',
        ocean: '#2563eb',
        pulse: '#f97316'
      }
    }
  },
  plugins: []
};

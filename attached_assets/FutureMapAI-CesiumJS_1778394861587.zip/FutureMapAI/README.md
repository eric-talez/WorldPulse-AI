# FutureMap AI — CesiumJS 3D Earth Explorer MVP

이 프로젝트는 업로드한 리포트/제안서의 아이디어를 바탕으로 만든 **실행 가능한 MVP 스타터 코드**입니다.

핵심 컨셉:

> 세계 뉴스·전쟁·질병·정치·경제·문화 이슈를 3D 지구에서 탐험하고, 그 변화가 내 직업과 미래 일자리에 어떤 영향을 주는지 AI 스타일로 분석해주는 글로벌 인사이트 플랫폼

이번 버전은 기존 평면 지도 UI를 **CesiumJS 기반 3D 지구 탐험 화면**으로 교체했습니다. 사용자는 Google Earth처럼 지구를 마우스로 드래그해 회전하고, 휠로 확대/축소하고, 국가 마커를 클릭해 해당 국가의 이슈·직업 리포트·포럼을 볼 수 있습니다.

현재 버전은 **API 키 없이 실행되는 mock-data MVP**입니다. 나중에 GDELT, WHO Disease Outbreak News, ACLED, OpenAI API를 붙일 수 있도록 백엔드 서비스 구조를 분리해 두었습니다.

---

## 1. 프로젝트 구조

```text
FutureMapAI/
├─ frontend/                 # React + TypeScript + Vite + Tailwind + CesiumJS UI
│  ├─ src/
│  │  ├─ components/         # 3D 지구, 패널, 직업 리포트, 포럼 UI
│  │  ├─ api/                # 백엔드 API 클라이언트
│  │  ├─ types.ts            # 공통 타입
│  │  └─ App.tsx
│  └─ package.json
│
├─ backend/                  # Spring Boot API 서버
│  ├─ src/main/java/com/futuremapai/
│  │  ├─ controller/         # REST API
│  │  ├─ dto/                # Request/Response DTO
│  │  ├─ model/              # 데이터 모델
│  │  └─ service/            # 비즈니스 로직 / mock 데이터 / AI 분석
│  └─ pom.xml
│
├─ docker-compose.yml        # PostgreSQL + Redis 준비용
├─ PROJECT_MAPPING.md        # 리포트 요구사항과 코드 매핑
└─ README.md
```

---

## 2. 빠른 실행 방법

### Backend 실행

```bash
cd backend
./mvnw spring-boot:run
```

만약 `mvnw`가 실행되지 않으면:

```bash
mvn spring-boot:run
```

백엔드 기본 주소:

```text
http://localhost:8080
```

헬스체크:

```text
http://localhost:8080/api/health
```

---

### Frontend 실행

새 터미널에서:

```bash
cd frontend
npm install
npm run dev
```

프론트엔드 기본 주소:

```text
http://localhost:5173
```

---

## 3. CesiumJS 3D 지구 기능

구현 위치:

```text
frontend/src/components/WorldMap.tsx
frontend/vite.config.ts
frontend/package.json
```

현재 구현된 3D 지구 기능:

- CesiumJS `Viewer` 기반 3D 지구 렌더링
- 마우스 click + drag로 지구 회전
- 마우스 wheel로 확대/축소
- 국가별 마커 표시
- 국가 마커 클릭 시 선택 국가 변경
- 선택 국가로 카메라 fly-to 이동
- 선택 국가 이슈 마커 표시
- risk score에 따른 마커 색상 변화
- 좌측/우측/하단 overlay UI로 사용법과 이슈 카드 표시

Cesium ion token은 필수로 넣지 않아도 됩니다. MVP는 Cesium local NaturalEarth imagery를 우선 사용하도록 설정했습니다. 나중에 Cesium ion terrain/imagery를 쓰고 싶으면 아래 환경변수를 추가하면 됩니다.

```bash
VITE_CESIUM_ION_TOKEN=your_cesium_ion_token_here
```

---

## 4. 현재 구현된 기능

### 프론트엔드

- Google Earth/CesiumJS 스타일 3D 지구 메인 화면
- 국가 마커 클릭
- 마우스 드래그 기반 지구 회전
- 확대/축소 탐험 UX
- 이슈 레이어 필터
  - 뉴스
  - 전쟁/분쟁
  - 질병
  - 정치
  - 경제
  - 문화
  - AI 직업 변화
- 국가별 이슈 사이드 패널
- 직업 입력 기반 AI 스타일 미래 리포트
- 국가/직업별 포럼 게시글
- 로그인 UI mock

### 백엔드

- `GET /api/countries` — 국가 목록
- `GET /api/issues` — 국가별/레이어별 이슈 조회
- `POST /api/job-reports/analyze` — 직업 미래 리포트 생성
- `GET /api/forum/posts` — 포럼 게시글 조회
- `POST /api/forum/posts` — 포럼 게시글 작성
- `POST /api/auth/login` — mock 로그인
- `GET /api/health` — 서버 상태 확인

---

## 5. API 연결 확장 포인트

현재는 mock data이지만, 다음 파일들에서 실제 API 연결로 확장하면 됩니다.

```text
backend/src/main/java/com/futuremapai/service/IssueService.java
backend/src/main/java/com/futuremapai/service/JobAnalysisService.java
backend/src/main/java/com/futuremapai/service/DataIngestionScheduler.java
```

추천 확장 순서:

1. GDELT API로 글로벌 뉴스 수집
2. WHO Disease Outbreak News API로 질병/감염병 이슈 수집
3. ACLED API로 분쟁/시위 데이터 수집
4. OpenAI API로 이슈 요약 및 직업 영향 분석
5. PostgreSQL에 country_issues / job_future_reports 저장
6. Redis로 국가별 이슈 캐싱
7. 소셜 로그인 추가
8. CesiumJS에 heatmap, cluster, 3D tiles, timeline layer 추가

---

## 6. Docker로 DB/Redis만 띄우기

현재 백엔드는 in-memory mock data로 돌아가므로 DB가 필수는 아닙니다. 나중에 PostgreSQL/Redis를 붙일 때 아래 명령을 사용하세요.

```bash
docker compose up -d
```

PostgreSQL:

```text
localhost:5432
DB: futuremap
USER: futuremap
PASSWORD: futuremap
```

Redis:

```text
localhost:6379
```

---

## 7. MVP 이후 추천 개발 단계

1. 3D globe 고도화
   - 국가 경계선 GeoJSON 표시
   - 이슈 밀도 heatmap
   - 국가별 risk color choropleth
   - 특정 국가 클릭 시 지구 zoom-in + issue timeline

2. 데이터 수집 Worker 추가
   - Scheduler가 주기적으로 GDELT/WHO/ACLED 데이터를 가져오도록 구현

3. AI 리포트 고도화
   - 국가 이슈 요약 + 직업명 + 산업 트렌드를 프롬프트로 넣어 OpenAI API 호출

4. DB 저장
   - country_issues
   - job_future_reports
   - forum_posts
   - users

5. 인증
   - email/password
   - Google OAuth
   - role: FREE / PRO / ADMIN

---

## 8. 제출/시연용 설명 문장

이 프로젝트는 “세계의 변화가 내 직업을 어떻게 바꾸는지 보여주는 AI 3D 지구 플랫폼”의 MVP입니다. 사용자는 CesiumJS 기반 3D 지구를 Google Earth처럼 회전·확대·축소하며 탐험하고, 국가를 클릭해 뉴스·분쟁·질병·정치·경제·문화·AI 직업 변화 레이어를 확인할 수 있습니다. 이후 본인의 직업을 입력하면 자동화 위험도, 성장 가능성, 필요한 역량, 국가별 기회를 분석받고, 국가/직업별 포럼에서 토론할 수 있습니다.
